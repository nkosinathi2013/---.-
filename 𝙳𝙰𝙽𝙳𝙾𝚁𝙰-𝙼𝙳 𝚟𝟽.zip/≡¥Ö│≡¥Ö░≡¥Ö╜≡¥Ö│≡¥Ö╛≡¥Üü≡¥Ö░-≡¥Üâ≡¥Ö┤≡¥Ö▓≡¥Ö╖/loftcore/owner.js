const settings = require('../settings');

async function ownerCommand(sock, chatId) {
  const vcardText = `
┏━━━━━┫ 𝙳𝙰𝙽𝙳𝙾𝚁𝙰-𝙼𝙳 𝚟𝟽 OWNER ┣━━━━━┓
┃
┃ ✦ *Name*      : ${ownerName}
┃ ✦ *Role*      : Founder • Developer • CEO
┃ ✦ *Contact*   : @${ownerNumber}
┃
┃ ⚡ Professional Multi-Device WhatsApp Bot
┃ 🌙 Powered by N𝙳𝙰𝙽𝙳𝙾𝚁𝙰-𝙼𝙳 𝚟𝟽 & 𝙳𝙰𝙽𝙳𝙾𝚁𝙰-𝚃𝙴𝙲𝙷
┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━┛
`;

  const caption = `Owner: 𝙳𝙰𝙽𝙳𝙾𝚁𝙰-𝚃𝙴𝙲𝙷
Phone: +27695667331

${vcardText.trim()}`;

  await sock.sendMessage(chatId, {
    image: { url: './image.jpg' },
    caption: caption
  });
}

module.exports = ownerCommand;