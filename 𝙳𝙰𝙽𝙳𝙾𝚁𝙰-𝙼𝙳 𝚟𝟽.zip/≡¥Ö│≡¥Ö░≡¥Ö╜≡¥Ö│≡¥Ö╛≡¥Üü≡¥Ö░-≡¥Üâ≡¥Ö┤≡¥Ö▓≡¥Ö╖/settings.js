const settings = {
  packname: '𝙳𝙰𝙽𝙳𝙾𝚁𝙰-𝙼𝙳 𝚟𝟽',
  author: '‎',
  botName: "𝙳𝙰𝙽𝙳𝙾𝚁𝙰-𝙼𝙳 𝚟𝟽",
  botOwner: 'nkosi_dandora', // Your name
  ownerNumber: '27695667331', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  maxStoreMessages: 20, 
  storeWriteInterval: 10000,
  description: "This is a bot for managing group commands and automating tasks.",
  version: "3.0.5",
  updateZipUrl: "https://github.com/xmdloft23/loft-quantum/archive/refs/heads/main.zip",
};

module.exports = settings;
